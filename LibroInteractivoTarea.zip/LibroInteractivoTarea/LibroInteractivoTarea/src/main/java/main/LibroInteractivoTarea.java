/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package main;

import controllador.ControlladorMenu;
import modelo.Libro;
import modelo.DatosLibro;
import vista.VistaMenu;

/**
 *
 * @author Jazmin
 */

public class LibroInteractivoTarea {
    public static void main(String[] args) {
        Libro libro = DatosLibro.creLibroQuijote();
        VistaMenu vMenu = new VistaMenu();
        ControlladorMenu ctrl = new ControlladorMenu(vMenu, libro);
        ctrl.iniciarMenu();
    }
}