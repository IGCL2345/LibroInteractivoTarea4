/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllador;

/**
 *
 * @author April
 */



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Libro;
import vista.VistaLibro;
import vista.VistaMenu;

public class ControlladorMenu implements ActionListener {
    private VistaMenu vista;
    private Libro libro;

    public ControlladorMenu(VistaMenu vista, Libro libro) {
        this.vista = vista;
        this.libro = libro;
        vista.addMenuListener(this);
    }

    public void iniciarMenu() {
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "INICIAR":
                abrirLibro();
                break;
            case "SALIR":
                System.exit(0);
                break;
        }
    }

    private void abrirLibro() {
        vista.setVisible(false);
        VistaLibro vLibro = new VistaLibro();
        new ControladorLibro(libro, vLibro, vista);
        vLibro.setLocationRelativeTo(null);
        vLibro.setVisible(true);
    }

}
