/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controllador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Evaluacion;
import modelo.Libro;
import modelo.Pagina;
import modelo.PaginaActividad;
import vista.VistaLibro;
import vista.VistaMenu;
import vista.Vista_Actividad;
import vista.Vista_Resultados;

/**
 *
 * @author April
 */
public class ControladorLibro implements ActionListener {

    private Libro libro;
    private VistaLibro vistaLibro;
    private VistaMenu vistaMenu;
    private Vista_Actividad vistaActividad;
    private Vista_Resultados vistaResultados;
    private PaginaActividad actividad;
    private Evaluacion evaluacion;
    private int indiceActual = 0;

    public ControladorLibro(Libro libro, VistaLibro vistaLibro, VistaMenu vistaMenu) {
        this.libro = libro;
        this.vistaLibro = vistaLibro;
        this.vistaMenu = vistaMenu;
        int posicion = libro.buscarIndiceActividad();
        actividad = (PaginaActividad) libro.obtenerPagina(posicion);
        evaluacion = new Evaluacion(actividad.obtenerRespuestasCorrectas(), 4);

        vistaActividad.addActividadListener(this);
        vistaResultados.addResultadosListener(this);

        vistaLibro.addLibroListener(this);
        ActualizarVista();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String op = e.getActionCommand();
        switch (op) {
            case "SIGUIENTE":
                if (indiceActual + 1 < libro.cantidadPaginas()) {
                    indiceActual++;
                }
                break;
            case "ANTERIOR":
                if (indiceActual > 0) {
                    indiceActual--;
                }
                break;
            case "ACTIVIDAD":
                if (evaluacion.hayIntentosDisponibles()) {
                    vistaActividad.cargarActividad(
                            actividad.obtenerEnunciados(), actividad.obtenerOpciones());
                    vistaLibro.setVisible(false);
                    vistaResultados.setVisible(false);
                    vistaActividad.setVisible(true);
                } else {
                    verResultados();
                }
                return;

            case "ENVIAR":
                int[] respuestas = vistaActividad.leerRespuestas();

                for (int i = 0; i < respuestas.length; i++) {
                    if (respuestas[i] < 1 || respuestas[i] > 4) {
                        JOptionPane.showMessageDialog(vistaActividad,
                                "Seleccioná una opción en la pregunta " + (i + 1));
                        return;
                    }
                }

                for (int i = 0; i < respuestas.length; i++) {
                    evaluacion.seleccionarRespuesta(i, respuestas[i]);
                }

                evaluacion.registrarIntento();
                verResultados();
                return;

            case "RESULTADOS":
                verResultados();
                return;

            case "VOLVER_LIBRO":
                vistaResultados.setVisible(false);
                vistaLibro.setVisible(true);
                return;

            case "VOLVER":
                vistaActividad.setVisible(false);
                volverMenu();
                return;

            case "MENU":
                volverMenu();
                return;
            case "SALIR":
                System.exit(0);
                break;
        }
        ActualizarVista();
    }

    public void volverMenu() {
        vistaLibro.dispose();
        vistaMenu.setVisible(true);
    }

    public void ActualizarVista() {
        try {
            Pagina p = libro.obtenerPagina(indiceActual);
            vistaLibro.mostrarPagina(
                    p.getTitulo(),
                    p.mostrarContenido(),
                    p.getNumeroPagina(),
                    libro.cantidadPaginas()
            );
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(vistaLibro, ex.getMessage());
        }
    }
    
    private void verResultados() {
    String texto = "";
    int cantidad = evaluacion.getIntentosRealizados();

    if (cantidad == 0) {
        texto = "Todavía no hay intentos.\n";
    }

    for (int i = 1; i <= cantidad; i++) {
        int[] respuestas = evaluacion.consultarIntento(i);
        int correctas = evaluacion.contarAciertos(respuestas);
        texto = texto + "Intento " + i + " - " + correctas + " de 3 correctas\n";
    }

    texto = texto + "Intentos restantes: " + evaluacion.getIntentosRestantes();

    vistaResultados.mostrarResultados(texto, evaluacion.hayIntentosDisponibles());
    vistaActividad.setVisible(false);
    vistaLibro.setVisible(false);
    vistaResultados.setVisible(true);
}
}
