/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Jazmin
 */
public class PaginaInformativa extends Pagina {
    
    private String ejemplos;

    public PaginaInformativa(String titulo, int numeroPagina, String contenido, String ejemplos) {
       super(titulo, numeroPagina, contenido);
       this.ejemplos = ejemplos;
    }
    
    public String getEjemplos(){
        return ejemplos;
    }

    @Override
    public String mostrarContenido() {
        return getContenido() + "\n\nEjemplos:\n" + ejemplos;
    }
    
    
}
