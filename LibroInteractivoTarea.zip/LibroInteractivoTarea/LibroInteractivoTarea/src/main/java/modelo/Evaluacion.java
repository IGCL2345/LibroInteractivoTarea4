/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Jazmin
 */
public class Evaluacion {

    private int maxIntentos = 3;

    private int[] respuestasCorrectas;
    private int[] respuestasSeleccionadas;
    private int[][] historial;
    private int cantidadOpciones;
    private int intentosRealizados;

    public Evaluacion(int[] respuestasCorrectas, int cantidadOpciones) {
        this.respuestasCorrectas = respuestasCorrectas;
        this.respuestasSeleccionadas = new int[respuestasCorrectas.length];
        this.historial = new int[maxIntentos][respuestasCorrectas.length];
        this.cantidadOpciones = cantidadOpciones;
        this.intentosRealizados = 0;
    }

    public int getMaxIntentos() {
        return maxIntentos;
    }

    public int getCantidadPreguntas() {
        return respuestasCorrectas.length;
    }

    public int getIntentosRealizados() {
        return intentosRealizados;
    }

    public int getIntentosRestantes() {
        return maxIntentos - intentosRealizados;
    }

    public boolean hayIntentosDisponibles() {
        return intentosRealizados < maxIntentos;
    }

    
    public void seleccionarRespuesta(int pregunta, int opcion) {
        if (opcion == 0) {
            throw new IllegalArgumentException("Debe contestar la pregunta " + (pregunta + 1) + ".");
        }
        if (opcion < 1 || opcion > cantidadOpciones) {
            throw new IllegalArgumentException("Respuesta inválida en la pregunta " + (pregunta + 1) + ".");
        }
        respuestasSeleccionadas[pregunta] = opcion;
    }

    
    public int registrarIntento() {
        if (intentosRealizados >= maxIntentos) {
            throw new IllegalStateException("Ya usó los " + maxIntentos + " intentos permitidos.");
        }

        for (int i = 0; i < respuestasSeleccionadas.length; i++) {
            historial[intentosRealizados][i] = respuestasSeleccionadas[i];
        }

        int aciertos = contarAciertos(historial[intentosRealizados]);
        intentosRealizados++;
        reiniciarSeleccion();
        return aciertos;
    }

    
    public int contarAciertos(int[] respuestas) {
        int aciertos = 0;
        for (int i = 0; i < respuestasCorrectas.length; i++) {
            if (respuestas[i] == respuestasCorrectas[i]) {
                aciertos++;
            }
        }
        return aciertos;
    }

    public boolean esCorrecta(int pregunta, int opcion) {
        return respuestasCorrectas[pregunta] == opcion;
    }

    
    public int[] consultarIntento(int numeroIntento) {
        if (numeroIntento < 1 || numeroIntento > intentosRealizados) {
            throw new IndexOutOfBoundsException("El intento " + numeroIntento + " no existe.");
        }
        return historial[numeroIntento - 1];
    }

    public int mejorResultado() {
        int mejor = 0;
        for (int i = 0; i < intentosRealizados; i++) {
            int aciertos = contarAciertos(historial[i]);
            if (aciertos > mejor) {
                mejor = aciertos;
            }
        }
        return mejor;
    }

    public void reiniciarSeleccion() {
        for (int i = 0; i < respuestasSeleccionadas.length; i++) {
            respuestasSeleccionadas[i] = 0;
        }
    }
}
