/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author April
 */
public class DatosLibro {
    public static Libro creLibroQuijote() {
        Libro libro = new Libro(
            "Don Quijote de la Mancha",
            "Lengua y Literatura Española",
            "Miguel de Cervantes"
        );

        // Página 1
        libro.agregarPagina(new PaginaInformativa(
            "Miguel de Cervantes y su obra", 1,
            "Miguel de Cervantes Saavedra (1547-1616) escribió El ingenioso hidalgo "
            + "don Quijote de la Mancha, publicada en dos partes: 1605 y 1615. "
            + "Es considerada la obra cumbre de la literatura española y una de las "
            + "más importantes de la literatura universal. Narra las aventuras de un "
            + "hidalgo que, tras leer demasiados libros de caballerías, pierde el juicio "
            + "y decide convertirse en caballero andante.",
            "Cervantes también escribió las Novelas ejemplares y Los trabajos de Persiles y Sigismunda."
        ));

        // Página 2
        libro.agregarPagina(new PaginaInformativa(
            "Personajes principales", 2,
            "Don Quijote: un hidalgo manchego que se hace llamar caballero andante. "
            + "Su verdadero nombre es Alonso Quijano. Sancho Panza: su escudero, un "
            + "labrador bonachón que lo acompaña esperando obtener el gobierno de una "
            + "ínsula. Dulcinea del Toboso: la dama idealizada de Don Quijote, en "
            + "realidad una labradora llamada Aldonza Lorenzo. Rocinante: su caballo, "
            + "flaco y viejo.",
            "Otros personajes: el cura, el barbero, Sansón Carrasco, el ventero, Maritornes."
        ));

        // Página 3
        libro.agregarPagina(new PaginaInformativa(
            "El lenguaje en Don Quijote", 3,
            "La obra mezcla varios registros: el lenguaje culto y arcaizante de Don "
            + "Quijote (influido por los libros de caballerías), el habla popular y "
            + "llena de refranes de Sancho Panza, y la narración culta del narrador. "
            + "Cervantes juega con la parodia del lenguaje caballeresco y utiliza "
            + "figuras como la ironía, la hipérbole y el contraste entre el ideal y "
            + "la realidad.",
            "Ejemplos: 'En un lugar de la Mancha, de cuyo nombre no quiero acordarme...' "
            + "y los refranes de Sancho como 'Más vale pájaro en mano que buitre volando'."
        ));

        // Página de actividad
        PaginaActividad act = new PaginaActividad(
            "Actividad: Pon a prueba lo aprendido", 4,
            "Responde las siguientes 3 preguntas sobre Don Quijote y el lenguaje. "
            + "Tienes 3 intentos."
        );

        act.agregarPregunta(new Pregunta(
            "¿Quién escribió Don Quijote de la Mancha?",
            new String[]{
                "Lope de Vega",
                "Miguel de Cervantes Saavedra",
                "Francisco de Quevedo",
                "Garcilaso de la Vega"
            },
            2
        ));

        act.agregarPregunta(new Pregunta(
            "¿Cuál es el verdadero nombre de Don Quijote?",
            new String[]{
                "Alonso Quijano",
                "Sancho Panza",
                "Sansón Carrasco",
                "Pedro Alonso"
            },
            1
        ));

        act.agregarPregunta(new Pregunta(
            "¿Qué recurso del lenguaje usa Sancho Panza con frecuencia?",
            new String[]{
                "El latín culto",
                "Los refranes populares",
                "Las rimas caballerescas",
                "Las citas de Aristóteles"
            },
            2
        ));

        libro.agregarPagina(act);
        return libro;
    }

}
