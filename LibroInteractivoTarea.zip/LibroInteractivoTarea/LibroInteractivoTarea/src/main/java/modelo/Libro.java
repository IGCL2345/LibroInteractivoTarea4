/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Jazmin
 */
public class Libro {

    private String titulo;
    private String tema;
    private String autor;
    private ArrayList<Pagina> paginas = new ArrayList<>();

    public Libro(String titulo, String tema, String autor) {
        this.titulo = titulo;
        this.tema = tema;
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getTema() {
        return tema;
    }

    public String getAutor() {
        return autor;
    }

    public void agregarPagina(Pagina pagina) {
        if (pagina == null) {
            throw new IllegalArgumentException("No se puede agregar una página nula.");
        }
        paginas.add(pagina);
    }

    public Pagina obtenerPagina(int indice) {
        if (indice < 0 || indice >= paginas.size()) {
            throw new IllegalArgumentException("La página " + (indice + 1) + " no existe en el libro.");
        }
        return paginas.get(indice);
    }

    public int cantidadPaginas() {
        return paginas.size();
    }

    public ArrayList<Pagina> getPaginas() {
        return paginas;
    }

    /**
     * Posición de la primera página de actividad, o -1 si no existe.
     */
    public int buscarIndiceActividad() {
        for (int i = 0; i < paginas.size(); i++) {
            if (paginas.get(i) instanceof PaginaActividad) {
                return i;
            }
        }
        return -1;
    }

}
