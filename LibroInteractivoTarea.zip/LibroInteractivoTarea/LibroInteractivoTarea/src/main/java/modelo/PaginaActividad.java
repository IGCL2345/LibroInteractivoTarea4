/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Jazmin
 */
public class PaginaActividad extends Pagina {

    //Uso de ArrayList 
    private ArrayList<Pregunta> preguntas = new ArrayList<>();

    public PaginaActividad(String titulo, int numeroPagina, String instrucciones) {
       super(titulo, numeroPagina, titulo);
     
    }

    public void agregarPregunta(Pregunta pregunta) {
        if (pregunta == null) {
            throw new IllegalArgumentException("La pregunta no puede ser nula");

        }
        preguntas.add(pregunta);
    }

    public Pregunta obtenerPregunta(int indice) {
        if (indice >= 0 && indice < preguntas.size()) {
            return preguntas.get(indice);
        }
        return null;
    }

    public int cantidadPreguntas() {
        return preguntas.size();
    }

    //Arreglos unidimensionales 
    public int[] obtenerRespuestasCorrectas() {
        int[] correctas = new int[preguntas.size()];
        for (int i = 0; i < correctas.length; i++) {
            correctas[i] = preguntas.get(i).getRespuestaCorrecta();
        }
        return correctas;
    }

    public String[] obtenerEnunciados() {
        String[] enunciados = new String[preguntas.size()];
        for (int i = 0; i < enunciados.length; i++) {
            enunciados[i] = preguntas.get(i).getEnunciado();
        }
        return enunciados;
    }

    //Arreglos bidimensionales 
    public String[][] obtenerOpciones() {
        String[][] opciones = new String[preguntas.size()][];
        for (int i = 0; i < opciones.length; i++) {
            opciones[i] = preguntas.get(i).getOpciones();
        }
        return opciones;
    }

    @Override
    public String mostrarContenido() {
        return getContenido() + "\n\nEsta actividad tiene " + preguntas.size()
                + "preguntas de selección unica";
    }

}
