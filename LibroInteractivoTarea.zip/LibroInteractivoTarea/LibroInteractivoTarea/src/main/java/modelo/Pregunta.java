/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Jazmin
 */
public class Pregunta {
    
    private String enunciado;
    private String [] opciones;
    private int respuestaCorrecta;
    
    public Pregunta(String enunciado, String[] opciones, int respuestaCorrecta){
        if(opciones == null || opciones.length < 2){
            //cambiar esto
            throw new IllegalArgumentException("Una pregunta necesita al menos dos opciones");
            
            
        }
        if(respuestaCorrecta < 1 || respuestaCorrecta > opciones.length){
            throw new IllegalArgumentException("La respuesta correcta debe estar entre 1 y" + opciones.length + ".");
        }
        
        this.enunciado = enunciado;
        this.opciones = opciones.clone();
        this.respuestaCorrecta = respuestaCorrecta;
    }
    
    public String getEnunciado(){
        return enunciado;
    }
    
    public String [] getOpciones(){
        return opciones.clone();
    }
    
    public int getRespuestaCorrecta(){
        return respuestaCorrecta;
    }
}
